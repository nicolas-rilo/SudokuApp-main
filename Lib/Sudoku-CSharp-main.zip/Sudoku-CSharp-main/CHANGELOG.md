# Change Log

All notable changes to the "Sudoku Game" will be documented in this file.

## [1.0.0] - 2020-11-17
- Initial release